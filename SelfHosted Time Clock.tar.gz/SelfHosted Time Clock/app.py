import os
import sqlite3
from datetime import datetime, timedelta
from functools import wraps

from flask import Flask, g, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = os.urandom(24)
app.config["SESSION_TIMEOUT_SECONDS"] = 30
DATABASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "clockin.db")


def get_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db


@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()


def init_db():
    with app.app_context():
        db = get_db()
        db.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                username TEXT UNIQUE,
                pin TEXT,
                password_hash TEXT,
                role TEXT NOT NULL DEFAULT 'employee',
                active INTEGER NOT NULL DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS time_entries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                entry_type TEXT NOT NULL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            );
            """
        )
        # Seed default admin if none exists
        cur = db.execute("SELECT id FROM users WHERE role = 'admin' LIMIT 1")
        if cur.fetchone() is None:
            db.execute(
                "INSERT INTO users (name, username, password_hash, role) VALUES (?, ?, ?, ?)",
                ("Admin", "admin", generate_password_hash("admin123"), "admin"),
            )
            db.commit()


# --- helpers ---

def _monday_of(dt):
    return (dt - timedelta(days=dt.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)


def _friday_of(dt):
    mon = _monday_of(dt)
    return mon + timedelta(days=4, hours=23, minutes=59, seconds=59)


def _sunday_of(dt):
    mon = _monday_of(dt)
    return mon + timedelta(days=6, hours=23, minutes=59, seconds=59)


def _calc_hours_for_range(user_id, start, end, db):
    rows = db.execute(
        "SELECT entry_type, timestamp FROM time_entries WHERE user_id = ? AND timestamp >= ? AND timestamp <= ? ORDER BY timestamp",
        (user_id, start.strftime("%Y-%m-%d %H:%M:%S"), end.strftime("%Y-%m-%d %H:%M:%S")),
    ).fetchall()
    total_seconds = 0
    lunch_seconds = 0
    last_clock_in = None
    last_lunch_start = None
    for r in rows:
        et = r["entry_type"]
        ts = datetime.strptime(r["timestamp"], "%Y-%m-%d %H:%M:%S")
        if et == "clock_in":
            last_clock_in = ts
        elif et == "clock_out":
            if last_clock_in:
                total_seconds += (ts - last_clock_in).total_seconds()
                last_clock_in = None
        elif et == "lunch_start":
            last_lunch_start = ts
        elif et == "lunch_end":
            if last_lunch_start:
                lunch_seconds += (ts - last_lunch_start).total_seconds()
                last_lunch_start = None
    # ongoing shifts / lunch within range
    now = datetime.now()
    if last_clock_in and last_clock_in <= end:
        total_seconds += (min(now, end) - last_clock_in).total_seconds()
    if last_lunch_start and last_lunch_start <= end:
        lunch_seconds += (min(now, end) - last_lunch_start).total_seconds()
    worked = max(0, total_seconds - lunch_seconds)
    return int(worked // 3600), int((worked % 3600) // 60)


# --- session timeout middleware ---

@app.before_request
def check_session_timeout():
    if request.endpoint in ("login", "logout", "static"):
        return
    if "user_id" in session:
        last = session.get("_last_activity")
        now = datetime.now().timestamp()
        if last and (now - last) > app.config["SESSION_TIMEOUT_SECONDS"]:
            session.clear()
            flash("Session expired due to inactivity.", "warning")
            return redirect(url_for("login"))
        session["_last_activity"] = now


# --- decorators ---

def login_required(role=None):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if "user_id" not in session:
                flash("Please log in.", "warning")
                return redirect(url_for("login"))
            if role and session.get("role") != role:
                flash("Access denied.", "danger")
                return redirect(url_for("login"))
            return f(*args, **kwargs)
        return decorated_function
    return decorator


# --- routes ---

@app.route("/")
def index():
    if session.get("role") == "admin":
        return redirect(url_for("admin_panel"))
    if session.get("user_id"):
        return redirect(url_for("employee_dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        login_type = request.form.get("login_type")
        if login_type == "admin":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            db = get_db()
            user = db.execute(
                "SELECT * FROM users WHERE username = ? AND role = 'admin'", (username,)
            ).fetchone()
            if user and check_password_hash(user["password_hash"], password):
                session["user_id"] = user["id"]
                session["role"] = user["role"]
                session["name"] = user["name"]
                session["_last_activity"] = datetime.now().timestamp()
                return redirect(url_for("admin_panel"))
            flash("Invalid admin credentials.", "danger")
        else:
            pin = request.form.get("pin", "").strip()
            db = get_db()
            user = db.execute(
                "SELECT * FROM users WHERE pin = ? AND role = 'employee' AND active = 1",
                (pin,),
            ).fetchone()
            if user:
                session["user_id"] = user["id"]
                session["role"] = user["role"]
                session["name"] = user["name"]
                session["_last_activity"] = datetime.now().timestamp()
                return redirect(url_for("employee_dashboard"))
            flash("Invalid PIN.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/employee", methods=["GET", "POST"])
@login_required(role="employee")
def employee_dashboard():
    user_id = session["user_id"]
    db = get_db()
    today = datetime.now().strftime("%Y-%m-%d")
    tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")

    if request.method == "POST":
        action = request.form.get("action")
        if action in ("clock_in", "clock_out", "lunch_start", "lunch_end"):
            db.execute(
                "INSERT INTO time_entries (user_id, entry_type) VALUES (?, ?)",
                (user_id, action),
            )
            db.commit()
        return redirect(url_for("employee_dashboard"))

    entries = db.execute(
        "SELECT * FROM time_entries WHERE user_id = ? AND timestamp >= ? AND timestamp < ? ORDER BY timestamp DESC",
        (user_id, today, tomorrow),
    ).fetchall()

    # --- daily status + hours ---
    clocked_in = False
    on_lunch = False
    total_seconds = 0
    lunch_seconds = 0
    last_clock_in = None
    last_lunch_start = None
    entries_chrono = list(reversed(entries))
    for e in entries_chrono:
        et = e["entry_type"]
        ts = datetime.strptime(e["timestamp"], "%Y-%m-%d %H:%M:%S")
        if et == "clock_in":
            last_clock_in = ts
            clocked_in = True
        elif et == "clock_out":
            if last_clock_in:
                total_seconds += (ts - last_clock_in).total_seconds()
                last_clock_in = None
            clocked_in = False
        elif et == "lunch_start":
            last_lunch_start = ts
            on_lunch = True
        elif et == "lunch_end":
            if last_lunch_start:
                lunch_seconds += (ts - last_lunch_start).total_seconds()
                last_lunch_start = None
            on_lunch = False

    now = datetime.now()
    if last_clock_in:
        total_seconds += (now - last_clock_in).total_seconds()
    if last_lunch_start:
        lunch_seconds += (now - last_lunch_start).total_seconds()

    worked_seconds = max(0, total_seconds - lunch_seconds)
    hours = int(worked_seconds // 3600)
    minutes = int((worked_seconds % 3600) // 60)

    # --- weekly hours ---
    now_dt = datetime.now()
    week_start = _monday_of(now_dt)
    week_end = _sunday_of(now_dt)
    pay_end = _friday_of(now_dt)

    week_hours, week_minutes = _calc_hours_for_range(user_id, week_start, week_end, db)
    pay_hours, pay_minutes = _calc_hours_for_range(user_id, week_start, pay_end, db)

    return render_template(
        "employee.html",
        entries=entries,
        clocked_in=clocked_in,
        on_lunch=on_lunch,
        hours=hours,
        minutes=minutes,
        week_hours=week_hours,
        week_minutes=week_minutes,
        pay_hours=pay_hours,
        pay_minutes=pay_minutes,
    )


@app.route("/admin")
@login_required(role="admin")
def admin_panel():
    db = get_db()
    employees = db.execute(
        "SELECT * FROM users WHERE role = 'employee' ORDER BY created_at DESC"
    ).fetchall()
    return render_template("admin.html", employees=employees)


@app.route("/admin/add_employee", methods=["POST"])
@login_required(role="admin")
def add_employee():
    name = request.form.get("name", "").strip()
    pin = request.form.get("pin", "").strip()
    if not name or not pin:
        flash("Name and PIN are required.", "danger")
        return redirect(url_for("admin_panel"))
    db = get_db()
    existing = db.execute("SELECT id FROM users WHERE pin = ?", (pin,)).fetchone()
    if existing:
        flash("PIN already in use.", "danger")
        return redirect(url_for("admin_panel"))
    db.execute(
        "INSERT INTO users (name, pin, role) VALUES (?, ?, 'employee')",
        (name, pin),
    )
    db.commit()
    flash("Employee added.", "success")
    return redirect(url_for("admin_panel"))


@app.route("/admin/remove_employee/<int:user_id>", methods=["POST"])
@login_required(role="admin")
def remove_employee(user_id):
    db = get_db()
    db.execute("UPDATE users SET active = 0 WHERE id = ? AND role = 'employee'", (user_id,))
    db.commit()
    flash("Employee removed.", "success")
    return redirect(url_for("admin_panel"))


@app.route("/admin/restore_employee/<int:user_id>", methods=["POST"])
@login_required(role="admin")
def restore_employee(user_id):
    db = get_db()
    db.execute("UPDATE users SET active = 1 WHERE id = ? AND role = 'employee'", (user_id,))
    db.commit()
    flash("Employee restored.", "success")
    return redirect(url_for("admin_panel"))


@app.route("/admin/entries/<int:user_id>", methods=["GET", "POST"])
@login_required(role="admin")
def view_entries(user_id):
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()

    if request.method == "POST":
        action = request.form.get("action")
        entry_id = request.form.get("entry_id", type=int)

        if action == "update" and entry_id:
            new_date = request.form.get("new_date", "").strip()
            new_time = request.form.get("new_time", "").strip()
            try:
                new_dt = datetime.strptime(f"{new_date} {new_time}", "%Y-%m-%d %H:%M:%S")
                db.execute(
                    "UPDATE time_entries SET timestamp = ? WHERE id = ? AND user_id = ?",
                    (new_dt.strftime("%Y-%m-%d %H:%M:%S"), entry_id, user_id),
                )
                db.commit()
                flash("Entry updated.", "success")
            except ValueError:
                flash("Invalid date/time format. Use YYYY-MM-DD HH:MM:SS", "danger")
            return redirect(url_for("view_entries", user_id=user_id))

        if action == "delete" and entry_id:
            db.execute(
                "DELETE FROM time_entries WHERE id = ? AND user_id = ?",
                (entry_id, user_id),
            )
            db.commit()
            flash("Entry deleted.", "success")
            return redirect(url_for("view_entries", user_id=user_id))

    entries = db.execute(
        "SELECT * FROM time_entries WHERE user_id = ? ORDER BY timestamp DESC",
        (user_id,),
    ).fetchall()
    return render_template("entries.html", user=user, entries=entries)


@app.route("/admin/change_password", methods=["POST"])
@login_required(role="admin")
def change_password():
    current = request.form.get("current_password", "")
    new_pass = request.form.get("new_password", "")
    confirm = request.form.get("confirm_password", "")
    db = get_db()
    user = db.execute(
        "SELECT * FROM users WHERE id = ?", (session["user_id"],)
    ).fetchone()
    if not check_password_hash(user["password_hash"], current):
        flash("Current password is incorrect.", "danger")
        return redirect(url_for("admin_panel"))
    if new_pass != confirm:
        flash("New passwords do not match.", "danger")
        return redirect(url_for("admin_panel"))
    if len(new_pass) < 4:
        flash("Password must be at least 4 characters.", "danger")
        return redirect(url_for("admin_panel"))
    db.execute(
        "UPDATE users SET password_hash = ? WHERE id = ?",
        (generate_password_hash(new_pass), session["user_id"]),
    )
    db.commit()
    flash("Password updated successfully.", "success")
    return redirect(url_for("admin_panel"))


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=int(os.environ.get("APP_PORT", 3000)), debug=True)
