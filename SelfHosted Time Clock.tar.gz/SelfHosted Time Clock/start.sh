#!/bin/bash
cd "$(dirname "$0")"

# If a local packages directory exists (from --target install), use it
if [ -d "packages" ]; then
    export PYTHONPATH="$(pwd)/packages${PYTHONPATH:+:$PYTHONPATH}"
fi

# If a virtual environment exists, prefer it
if [ -d ".venv" ] && [ -f ".venv/bin/python3" ]; then
    PYTHON="$(pwd)/.venv/bin/python3"
else
    PYTHON="python3"
fi

# Clear any conflicting PYTHONHOME from AppImage wrappers
env -u PYTHONHOME "$PYTHON" app.py
